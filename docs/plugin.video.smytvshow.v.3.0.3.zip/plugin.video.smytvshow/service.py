# -*- coding: utf-8 -*-
#------------------------------------------------------------
# smytvshow
# XBMC service entry point
# http://smystero.dlinkddns.org/smytvwhow/
#------------------------------------------------------------

# Constants

import xbmc

from xbmcutils import logger

class main:

    def __init__(self):
        logger.info("Service started")
        from smtvsinterface import smtvs_api
        try:
            sm = smtvs_api.smtvs()
            try:
                from xbmcutils import config
                try:
                    if config.get_setting("smtvs_id") == "":
                        sm.new_install()
                    else:
                        if not (config.get_setting("smtvs_ver") == config.get_version()):
                            sm.upd_install()
                except Exception, e:
                    logger.error(e.message)
                finally:
                    del config

            except Exception, e:
                logger.error(e.message)
            finally:
                del sm
        except Exception, e:
            logger.error(e.message)
        finally:
            del smtvs_api

        try:
            import updater as upd
            try:
                updater = upd.Updater()
                try:
                    updater.update()
                finally:
                    del updater
            except Exception, e:
                logger.error(e.message)
            finally:
                del upd

        except Exception,e:
            logger.error(e.message)

        while (not xbmc.abortRequested):
            xbmc.sleep(1000)

        logger.info("Service stopped")

main()