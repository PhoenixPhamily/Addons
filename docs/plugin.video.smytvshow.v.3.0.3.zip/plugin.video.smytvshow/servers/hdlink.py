# -*- coding: utf-8 -*-
#------------------------------------------------------------
# smytvshow
# BACKIN server connector
# http://smystero.dlinkddns.org/smytvwhow/
#------------------------------------------------------------

import re

from core import scrapertools, common as c, servertools
from xbmcutils import logger

SERVER_NAME = "[HDLink]"
SERVER_ID = "hdlink"


def find_videos(data):
    logger.debug("start...")

    found = set()

    url_list = []

    #<a href="http://backin.net/0hmi0bn6sy57">Backin</a>
    patron = 'hdlink.video/l/([^?]+)'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for match in matches:
        url = "http://hdlink.video/l/%s" % match
        if url not in found :
            headers = scrapertools.def_headers
            headers.append(['Referer', 'http://hdlink.video/'])
            data2 = scrapertools.cache_page(url, headers=headers)
            patron = '<a id="mlink_([^"]+)"'
            avail_mlink = re.compile(patron).findall(data2)

            for mlink in avail_mlink:
                serverurl = "%s?host=%s" % (url, mlink)
                data3 = scrapertools.cache_page(serverurl, headers=headers)
                patron = '<div class="mainplayer">(.*?)</div>'
                serverdata = c.find_single_match(data3,patron)
                url_list.extend(servertools.find_videos(serverdata))

            #url_list.append([SERVER_ID, SERVER_NAME, url, match])
            found.add(url)

    logger.debug("end...")
    return url_list


def get_video_url(page_url):
    logger.debug("start...")

    video_urls = []

    logger.debug("end...")
    return video_urls
