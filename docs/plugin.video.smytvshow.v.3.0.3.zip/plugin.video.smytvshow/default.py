# -*- coding: utf-8 -*-
#------------------------------------------------------------
# smytvshow
# XBMC entry point
# http://smystero.dlinkddns.org/smytvwhow/
#------------------------------------------------------------

# Constants

from xbmcutils import cache
from core import dispatcher

#from xbmcutils import config
__plugin__  = "smytvshow"
__author__  = "smystero.org"
__url__     = "http://smystero.dlinkddns.org/smytvshow/"
__date__ = "09/03/2015"
__version__ = "0.0.1"

c = cache.CacheManager()
c.check()
del c

dispatcher.dispatch()


