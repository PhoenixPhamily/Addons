# -*- coding: utf-8 -*-
#------------------------------------------------------------
# smytvshow
# Javascript Unescape decoder
# http://smystero.dlinkddns.org/smytvwhow/
#------------------------------------------------------------

import re
def unescape(par1, par2, par3):
    var1 = par1
    for ii in xrange(0, len(par2)):
        var1 = re.sub(par2[ii], par3[ii], var1)

    var1 = re.sub("%26", "&", var1)
    var1 = re.sub("%3B", ";", var1)
    return var1.replace('<!--?--><?', '<!--?-->')

