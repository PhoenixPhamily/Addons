# -*- coding: utf-8 -*-
#------------------------------------------------------------
# smytvshow
# Decrypt link base64 // python version of speedvideo's base64_decode() [javascript]
# http://smystero.dlinkddns.org/smytvwhow/
# ADAPTED FROM
#------------------------------------------------------------
# pelisalacarta - XBMC Plugin
# Conector para speedvideo
# by be4t5
# http://blog.tvalacarta.info/plugin-xbmc/pelisalacarta/
#------------------------------------------------------------

def decode(link, numero):
    link1= link[0:numero]
    link2= link[numero+10:]
    link= link1+link2

    alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="

    if (not link):
        return link

    link += ""

    i=0
    k=0
    array = [""]*1000
    while True:
        a= alfabeto.index(link[i])
        i=i+1
        b= alfabeto.index(link[i])
        i=i+1
        c= alfabeto.index(link[i])
        i=i+1
        d= alfabeto.index(link[i])
        i=i+1
        e= a << 18 | b << 12 | c << 6 | d
        e7 = e >> 16&0xff
        e8 = e >> 8&0xff
        e9 = e&0xff
        uno= [e7,e8]
        due = [e7]
        tre = [e7,e8,e9]
        if(c==64):
            array[k] = ''.join(map(unichr, due))
            k=k+1
        else:
            if (d==64):
               array[k] = ''.join(map(unichr, uno))
               k=k+1
            else:
               array[k] = ''.join(map(unichr, tre))
               k=k+1
        if(i>= len(link)):
            break

    link= "".join(array)

    return link