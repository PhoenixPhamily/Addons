# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# smytvshow
# pusher_info
# http://smystero.dlinkddns.org/smytvwhow/
# ------------------------------------------------------------


class PusherInfo(object):
    def __init__(self, count, target, title, extra={}):
        self.target_type = 'P'
        self.target = target
        self.title = "%02d - %s" % (count, title)
        self.extra = extra
