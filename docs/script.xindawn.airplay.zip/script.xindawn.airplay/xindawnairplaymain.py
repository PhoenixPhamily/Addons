#import rpdb2 
#rpdb2.start_embedded_debugger('pw')
import xbmc
import xbmcaddon
import xbmcgui
import time
import os
import threading

#import lib.common
#ifrom lib.common import log, dialog_yesno, dialog_ok
#ifrom lib.common import upgrade_message as _upgrademessage
#ifrom lib.common import upgrade_message2 as _upgrademessage2

__settings__       = xbmcaddon.Addon(id='script.xindawn.airplay')
__cwd__            = __settings__.getAddonInfo('path')
__icon__            = os.path.join(__cwd__,"icon.png")
__scriptname__   = "XinDawn AirPlay/AirPlay Mirroring"

__libnameosx__ = "libmediaserver.dylib"
__libnameios__ = "airmediaserver.0.dylib"
__libnamewin__ = "airmediaserve.dll"
__libnamesdlwin__ = "SDL.dll"
__libnamesdlosx__ = "libSDL-1.2.0.dylib"
__libnameandroid__ = "libmediaserver.so"

BASE_RESOURCE_PATH = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) )
AIRPLAY_TEMP_IMAGE_PATH = xbmc.translatePath(os.path.join('special://temp','airplay_photo.jpg'))
sys.path.append (BASE_RESOURCE_PATH)

from settings import *
from airplaymediaserver import airmediaserver_loadLib
from airplaymediaserver import airmediaserver_init
from airplaymediaserver import airmediaserver_stop
from airplaymediaserver import airplay_initGlobals
from airplaymediaserver import airplay_get_mediainfo

global g_abortRequested 
global g_airplaymediaserverAvailable

def log(loglevel, msg):  
  xbmc.log("### [%s] - %s" % (__scriptname__,msg,),level=loglevel ) 
  
def initGlobals():
  settings_initGlobals()
  airplay_initGlobals()

def initServers():
   ret = 0
   macAdr = settings_getMacAddress()
   friendlyName = settings_getFriendlyName()
   activecode = settings_getActiveCode()
   trialenable = settings_getTrialEnable()
   log(xbmc.LOGERROR, "%s" % activecode)
   log(xbmc.LOGERROR, "%s" % trialenable)
   if activecode != "" :
        ret = airmediaserver_init(friendlyName, macAdr, settings_getPasswordLock(), settings_getPassword(), settings_getAirtunesServerPort(), settings_getAirplayServerPort(), settings_getAirplayDataPort(),settings_getAirplayRotation(),  activecode)
   elif  trialenable == True :
        ret = airmediaserver_init(friendlyName, macAdr, settings_getPasswordLock(), settings_getPassword(), settings_getAirtunesServerPort(), settings_getAirplayServerPort(), settings_getAirplayDataPort(),settings_getAirplayRotation(),"000000000")
   else :   
        ret = 8
   #log(xbmc.LOGERROR, "%s 2" % ret)
   if ret == 0 :
    t1 = __settings__.getLocalizedString(520)
    xbmcgui.Dialog().notification(__scriptname__,t1,  xbmcgui.NOTIFICATION_INFO, 10000,True) 
   elif  ret == 1 :
    #log(xbmc.LOGERROR, "%s 3" % ret)
    t1 = __settings__.getLocalizedString(517)
    t2 = __settings__.getLocalizedString(518)
    t3 = __settings__.getLocalizedString(519)
    xbmcgui.Dialog().ok(__scriptname__,t1,t2,t3)
   elif ret == 2 :
    t1 = __settings__.getLocalizedString(514)
    xbmcgui.Dialog().ok(__scriptname__,t1)
   elif ret == 3 :
    t1 = __settings__.getLocalizedString(512)
    xbmcgui.Dialog().ok(__scriptname__,t1)
   elif ret == 4 :
    t1 = __settings__.getLocalizedString(515)
    xbmcgui.Dialog().ok(__scriptname__,t1)
   elif ret == 5 :
    t1 = __settings__.getLocalizedString(513)
    xbmcgui.Dialog().ok(__scriptname__,t1)
   elif ret == 6 :
    t1 = __settings__.getLocalizedString(526)
    xbmcgui.Dialog().ok(__scriptname__,t1)
   elif ret == 8 :
    t1 = __settings__.getLocalizedString(522)
    t2 = __settings__.getLocalizedString(523)
    t3 = __settings__.getLocalizedString(524)
    xbmcgui.Dialog().ok(__scriptname__,t1,t2,t3)
   elif ret == 20 :
    t1 = __settings__.getLocalizedString(525)
    xbmcgui.Dialog().ok(__scriptname__,t1)
    t2 = __settings__.getLocalizedString(520)
    xbmcgui.Dialog().notification(__scriptname__,t2,  xbmcgui.NOTIFICATION_INFO, 10000,True) 
   else:
    t1 = __settings__.getLocalizedString(521)
    xbmcgui.Dialog().ok(__scriptname__,t1)
#    dialog_ok(504)

  
def deinitServers():
  airmediaserver_stop()


def process_airmediaserver():
  global g_airplaymediaserverAvailable
  global g_abortRequested 
  g_abortRequested = False
  while not g_abortRequested:
        initServers()
        #log(xbmc.LOGERROR, "process_airplay===================== 1.")
        while not g_abortRequested:
            time.sleep(0.5)
            airplay_get_mediainfo()
            #on settings change -> around the world
            if settings_checkForNewSettings():
                break
        deinitServers()
  #log(xbmc.LOGERROR, "process_airplay===================== 2.")
    



#MAIN - entry point
initGlobals()
loaded = airmediaserver_loadLib()


if loaded == 0:
  g_airplaymediaserverAvailable = True
else:
  log(xbmc.LOGERROR, "xindawn airplaymediaserver not available or not support - disable airplay/airplay mirroring support.")
#main loop
settings_setup()
process_airmediaserver()    #airplay loop
log(xbmc.LOGDEBUG,"xindawn airplaymediaserver script cleaned up")
