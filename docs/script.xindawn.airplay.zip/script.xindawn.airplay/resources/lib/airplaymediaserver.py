import platform
import xbmc
import xbmcgui
import sys
import os

__scriptname__ = sys.modules[ "__main__" ].__scriptname__
__settings__ = sys.modules[ "__main__" ].__settings__
__cwd__ = sys.modules[ "__main__" ].__cwd__
AIRPLAY_TEMP_IMAGE_PATH = sys.modules["__main__"].AIRPLAY_TEMP_IMAGE_PATH

__libnameosx__ = sys.modules[ "__main__" ].__libnameosx__
__libnameios__ = sys.modules[ "__main__" ].__libnameios__
__libnamewin__ = sys.modules[ "__main__" ].__libnamewin__
__libnamesdlwin__ = sys.modules[ "__main__" ].__libnamesdlwin__
__libnamesdlosx__ = sys.modules[ "__main__" ].__libnamesdlosx__
__libnameandroid__ = sys.modules[ "__main__" ].__libnameandroid__

from settings import *



global g_isPlaying
global g_isPaused
global g_firstDuration
global g_isPlaybackReallyStarted




global g_airmediaserverLoaded
global g_libairmediaserver
global g_printfCallback
global g_ao
g_printfCallback = None
g_ao = None

try:
  from ctypes import *
  HAVE_CTYPES = True
except:
  HAVE_CTYPES = False

  
def log(loglevel, msg):  
  xbmc.log("### [%s] - %s" % ('XinDawn AirPlayMediaServer',msg,),level=loglevel ) 
  
  

extprintf_prototype = CFUNCTYPE(c_int, c_char_p, c_size_t)
#extprintf_prototype = WINFUNCTYPE(c_int, c_char_p, c_size_t) #windows


class printfPtr(Structure):
  _fields_ = [("extprintf",  extprintf_prototype)]
  

airplay_open_prototype     = CFUNCTYPE(None,  c_char_p, c_float);
airplay_play_prototype    = CFUNCTYPE(None);
airplay_pause_prototype  = CFUNCTYPE(None);
airplay_stop_prototype    = CFUNCTYPE(None);
airplay_seek_prototype  = CFUNCTYPE(None, c_float);
airplay_setvolume_prototype  = CFUNCTYPE(None, c_int);
airplay_showphoto_prototype  = CFUNCTYPE(None, c_char_p);

airplay_mirroring_play_prototype  = CFUNCTYPE(None, c_char_p,c_char_p);
airplay_mirroring_process_prototype  = CFUNCTYPE(None, c_char_p,c_int, c_int, c_double );
airplay_mirroring_stop_prototype  = CFUNCTYPE(None);

airplay_audio_init_prototype  = CFUNCTYPE(None, c_int, c_int, c_int, c_int);
airplay_audio_process_prototype  = CFUNCTYPE(None, c_char_p, c_int,c_double, c_uint );
airplay_audio_setvolume_prototype  = CFUNCTYPE(None, c_int);
airplay_audio_destory_prototype  = CFUNCTYPE(None);

class AirPlayCallback(Structure):     
  _fields_ = [('AirPlayPlayback_Open',    airplay_open_prototype),
                 ('AirPlayPlayback_Play',    airplay_play_prototype),
                ('AirPlayPlayback_Pause',    airplay_pause_prototype),
                ('AirPlayPlayback_Stop',    airplay_stop_prototype),
                ('AirPlayPlayback_Seek',    airplay_seek_prototype),
                ('AirPlayPlayback_SetVolume',  airplay_setvolume_prototype), 
                ('AirPlayPlayback_ShowPhoto',  airplay_showphoto_prototype), 
                ('AirPlayMirroring_Play',    airplay_mirroring_play_prototype),
                ('AirPlayMirroring_Process',    airplay_mirroring_process_prototype),
                ('AirPlayMirroring_Stop',    airplay_mirroring_stop_prototype),
                ('AirPlayAudio_Init',    airplay_audio_init_prototype),
                ('AirPlayAudio_Process',  airplay_audio_process_prototype), 
                ('AirPlayAudio_SetVolume',  airplay_audio_setvolume_prototype),          
                ('AirPlayAudio_destroy',  airplay_audio_destory_prototype)]  
  
  
def airplay_initGlobals():
    global g_isPlaying
    global g_isPaused
    global g_firstDuration
    global g_isPlaybackReallyStarted
    g_isPlaying = False
    g_isPaused = False
    g_firstDuration = True
    g_isPlaybackReallyStarted = False

  
  
def airplay_open(url, pos):
   log(xbmc.LOGDEBUG, "%f" % pos)
   airplay_initGlobals()
   position = float(pos)
   #listitem = xbmcgui.ListItem()      
   #listitem.setProperty('mimetype', 'video/avc')
   #xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER).play(url, listitem)
   if position > 0.0:
        posPercent = position * 100
        listitem = xbmcgui.ListItem()      
        listitem.setProperty('StartPercent', str(posPercent))
        xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER).play(url, listitem)
   else:
        xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER).play(url)
   
def airplay_play():
  if xbmc.getCondVisibility("Player.Paused"):
        xbmc.executebuiltin('Action(play)')
        #log(xbmc.LOGDEBUG, "%s" % b"play")

def airplay_pause():
   print("airplay_pause" )   
   if xbmc.getCondVisibility("Player.Playing"):
        xbmc.executebuiltin('Action(pause)')
        #log(xbmc.LOGDEBUG, "%s" % b"pause")
   
        
def airplay_stop():
    global g_isPlaybackReallyStarted
    if g_isPlaying: #only stop player if we started him
      xbmc.executebuiltin('PlayerControl(Stop)')
      g_isPlaybackReallyStarted = False
    else: #if we are not playing and get the stop request - we just wanna stop picture streaming
      xbmc.executebuiltin('Action(previousmenu)')
   #xbmc.executebuiltin('PlayerControl(Stop)')
   #print("airplay_stop" )
   
def airplay_seek(pos):
    duration = getCurrentDurationSecs()
    posPercent = float(float(pos)*100 / duration)
    xbmc.executebuiltin('playercontrol(seekpercentage(' + str(posPercent) + '))')
    
def airplay_setvolume(volume):
    xbmc.executebuiltin("SetVolume(%d,showvolumebar)" % volume)
    
def airplay_showphoto(name):
    log(xbmc.LOGDEBUG, "%s" % name)
    xbmc.executebuiltin('ShowPicture('+name+')')
   
def timeToSecs(timeAr):
  arLen = len(timeAr)
  if arLen == 1:
    if len(timeAr[0]) > 0:
      currentSecs = int(timeAr[0])
    else:
      currentSecs = 0
  elif arLen == 2:
    currentSecs = int(timeAr[0]) * 60 + int(timeAr[1])
  elif arLen == 3:
    currentSecs = int(timeAr[0]) * 60 * 60 + int(timeAr[1]) * 60 + int(timeAr[2])
  return currentSecs   
   
def getCurrentTimeSecs():
  currentTimeAr = xbmc.getInfoLabel("Player.Time").split(":")
  return timeToSecs(currentTimeAr)

def getCurrentDurationSecs():
  currentDurationAr = xbmc.getInfoLabel("Player.Duration").split(":")
  return timeToSecs(currentDurationAr)   
   
def airplay_get_mediainfo():
    global g_isPlaybackReallyStarted
    global g_firstDuration
    global g_isPlaying
    global g_isPaused
    hasVideo = xbmc.getCondVisibility("Player.Playing") or xbmc.getCondVisibility("Player.Paused")
    playing = False
    paused = False
    
    if hasVideo:
      g_isPlaybackReallyStarted = True
      duration = getCurrentDurationSecs()
      if duration > 0:
        if g_firstDuration:
            g_firstDuration = False
            currentDuration = xbmc.getInfoLabel("Player.Duration")
            #log(xbmc.LOGDEBUG, "%s" % currentDuration)
            g_libairmediaserver.UpdateState(0x100,currentDuration, None )
        currentTime = xbmc.getInfoLabel("Player.Time")
        #log(xbmc.LOGDEBUG, "%s" % currentTime)
        g_libairmediaserver.UpdateState(0x101,currentTime, None )
        playing = xbmc.getCondVisibility("Player.Playing")
        if g_isPlaying == False and playing == True :
            g_libairmediaserver.UpdateState(0x102,c_char_p(b"PLAYING"), None )
            g_isPlaying = True
            #log(xbmc.LOGDEBUG, "%s" % b"PLAYING")
        paused = xbmc.getCondVisibility("Player.Paused")
        if g_isPaused == False and paused == True :
            g_libairmediaserver.UpdateState(0x102,c_char_p(b"PAUSED_PLAYBACK"), None )
            g_isPaused = True
            #log(xbmc.LOGDEBUG, "%s" % b"PAUSED_PLAYBACK")
        if g_isPaused == True and paused == False :
            g_libairmediaserver.UpdateState(0x102,c_char_p(b"PLAYING"), None )
            g_isPaused = False
            #log(xbmc.LOGDEBUG, "%s" % b"PLAYING")  
    else:#no video playing
        if g_isPlaybackReallyStarted and g_isPlaying:
            g_libairmediaserver.UpdateState(0x102,c_char_p(b"STOPPED"), None )
            g_isPlaybackReallyStarted = False
            #log(xbmc.LOGDEBUG, "%s" % b"STOPPED")  


def airmediaserver_loadLib():
  global g_airmediaserverLoaded
  global g_libairmediaserver  
  ret = 0
  if HAVE_CTYPES:
    libname = "airmediaserver.so" #default to linux type
    try:
      if xbmc.getCondVisibility('system.platform.android'):
        libname = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib', __libnameandroid__) )
        if not os.path.exists(libname):
          ret = 1
        else:
          cdll.LoadLibrary(libname)
          g_libairmediaserver = CDLL(libname)
      elif xbmc.getCondVisibility('system.platform.osx'):
        libname = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib','osx', __libnameosx__) )
        if not os.path.exists(libname):
          ret = 1
        else:
          cdll.LoadLibrary(libname)
          g_libairmediaserver = CDLL(libname)
      elif  xbmc.getCondVisibility('system.platform.ios'):
        libname = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib', __libnameios__) )
        if not os.path.exists(libname):
          ret = 1
        else:
          cdll.LoadLibrary(libname)
          g_libairmediaserver = CDLL(libname)
      elif xbmc.getCondVisibility('system.platform.windows'): 
        libname = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib', 'windows', __libnamewin__) )
        if not os.path.exists(libname):
          ret = 1
        else:
          cdll.LoadLibrary(libname)
          g_libairmediaserver = CDLL(libname)
      else:
        cdll.LoadLibrary("airmediaserver.so")
        g_libairmediaserver = CDLL("airmediaserver.so")
        
        g_libairmediaserver.UpdateState.argtypes=(c_int, c_char_p, c_char_p)
        g_libairmediaserver.StartMediaServer.restype=c_int
        g_libairmediaserver.StartMediaServer.argtypes = [c_char_p, c_char_p,c_char_p,  c_int, c_int, c_int,c_int, c_int, c_int, c_int,c_char_p, c_char_p,c_int,POINTER(AirPlayCallback)]
        g_libairmediaserver.StopMediaServer.argtypes = [None]
        #g_libairmediaserver.StartMediaServer.argtypes = [c_char_p, c_char_p, c_int, c_int, c_int, c_int, c_int,POINTER(AirPlayCallback)]
    except:
      g_airmediaserverLoaded = False
      log(xbmc.LOGERROR, "XinDawn AirPlayMediaServer: Error loading " + libname)
      ret = 1
  else:
    log(xbmc.LOGERROR, "XinDawn AirPlayMediaServer: No ctypes available.")
    ret = 2
    g_airmediaserverLoaded = False
  return ret
  
def airmediaserver_log(cls, lev, msg):  
    #print("%s" % (msg))
    log(xbmc.LOGDEBUG, "%s" % msg)
    return 1
 
def airmediaserver_init(friendlyName, macAdr,passwordlock,  password, airtunesport, airplayport, airplaydataport, airplayrotation, activecode):
  global g_ao
  ret = 0
  rotation = 0
  libsdl =""
  airplay_initGlobals()
  g_ao = AirPlayCallback()
  g_ao.AirPlayPlayback_Open    = airplay_open_prototype(airplay_open)
  g_ao.AirPlayPlayback_Play   = airplay_play_prototype(airplay_play)
  g_ao.AirPlayPlayback_Pause = airplay_pause_prototype(airplay_pause)
  g_ao.AirPlayPlayback_Stop   = airplay_stop_prototype(airplay_stop)
  g_ao.AirPlayPlayback_Seek   = airplay_seek_prototype( airplay_seek)
  g_ao.AirPlayPlayback_SetVolume = airplay_setvolume_prototype(airplay_setvolume)
  g_ao.AirPlayPlayback_ShowPhoto = airplay_showphoto_prototype(airplay_showphoto)
  
  if xbmc.getCondVisibility('system.platform.windows'): 
    libsdl = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib','windows',  __libnamesdlwin__) )
  
  if xbmc.getCondVisibility('system.platform.osx'):
    libsdl = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib','osx',  __libnamesdlosx__) )

  log(xbmc.LOGERROR, "XinDawn AirPlayMediaServer: Error loading " + libsdl)
  
  if airplayrotation == True :
    rotation = 1
  else :
    rotation = 0  
  #log(xbmc.LOGERROR, "%s" % activecode)
  if passwordlock == True :
    ret = g_libairmediaserver.StartMediaServer(friendlyName,AIRPLAY_TEMP_IMAGE_PATH,libsdl, 1280,720,60,airtunesport,airplayport,airplaydataport, 0, password, activecode, 80*1024, pointer(g_ao))
  else :
    ret =  g_libairmediaserver.StartMediaServer(friendlyName,AIRPLAY_TEMP_IMAGE_PATH, libsdl,1280,720,60,airtunesport,airplayport,airplaydataport, 0, c_char_p(b""), activecode, 80*1024, pointer(g_ao))
 
  #g_libairmediaserver.StartMediaServer(c_char_p(b"XBMC-GameBox(XinDawn)"),AIRPLAY_TEMP_IMAGE_PATH, 1280,720,47000,7000,80*1024, pointer(g_ao))
  #log(xbmc.LOGERROR, "%s" % ret)
  return ret

def airmediaserver_stop():
    g_libairmediaserver.StopMediaServer()



  



