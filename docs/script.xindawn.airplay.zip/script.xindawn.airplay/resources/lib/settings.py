'''
    AirPlay for XBMC
    Copyright (C) 2012 Team XBMC

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys
import time
import xbmc
__scriptname__ = sys.modules[ "__main__" ].__scriptname__
__settings__   = sys.modules[ "__main__" ].__settings__
__cwd__        = sys.modules[ "__main__" ].__cwd__
__icon__       = sys.modules[ "__main__" ].__icon__
sys.path.append (__cwd__)

#general
global g_airplayFriendlyName 
global g_airplayServerport
global g_airtunesServerport
global g_airplayDataport
global g_airplayRotation
global g_airtunesDebug
global g_passwordlock
global g_password
global g_trialEnable
global g_activecode
global g_macAddress
global g_timer

#init globals with defaults
def settings_initGlobals():
  global g_airplayFriendlyName 
  global g_airplayServerport
  global g_airtunesServerport
  global g_airplayDataport
  global g_airplayRotation
  global g_airtunesDebug
  global g_passwordlock
  global g_trialEnable
  global g_password
  global g_activecode
  global g_macAddress
  global g_timer
  
  g_airplayFriendlyName  ="XBMC-GAMEBOX(Xindawn)"
  g_airplayServerport     = 7000
  g_airtunesServerport   =47000
  g_airplayDataport       = 7100
  g_airplayRotation        = False
  g_airtunesDebug         = False
  g_passwordlock          = False
  g_password	            = ""
  g_trialEnable              = False
  g_activecode             =""
  g_macAddress            = xbmc.getInfoLabel("Network.MacAddress")
  if not ":" in g_macAddress:
    time.sleep(2)
    g_macAddress            = xbmc.getInfoLabel("Network.MacAddress")
  g_timer = time.time()
   
def settings_getAirplayServerPort():
  global g_airplayServerport
  return g_airplayServerport 

def settings_getAirtunesServerPort():
  global g_airtunesServerport
  return g_airtunesServerport 
  
def settings_getAirplayDataPort():
  global g_airplayDataport
  return g_airplayDataport 
  
def settings_getAirplayRotation():
  global g_airplayRotation
  return g_airplayRotation  
  

def settings_getAirtunesDebug():
  global g_airtunesDebug
  return g_airtunesDebug

def settings_getPasswordLock():
	global g_passwordlock
	return g_passwordlock
	
def settings_getPassword():
	global g_password
	return g_password
    
def settings_getTrialEnable():
  global g_trialEnable
  return g_trialEnable
  
def settings_getFriendlyName():
  global g_airplayFriendlyName
  return g_airplayFriendlyName
 
def settings_getMacAddress():
  global g_macAddress
  return g_macAddress

def settings_getActiveCode():
  global g_activecode
  return g_activecode

#check for new settings and handle them if anything changed
#only checks if the last check is 5 secs old
#returns true if settings have changed
def settings_checkForNewSettings():
#todo  for now impl. stat on addon.getAddonInfo('profile')/settings.xml and use mtime
#check for new settings every 5 secs
  global g_timer
  ret = False

  if time.time() - g_timer > 5:
    ret = settings_setup()
    g_timer = time.time()
  return ret
  
def settings_handleAirplaySettings():
  global g_airplayFriendlyName
  global g_airplayServerport
  global g_airtunesServerport
  global g_airplayDataport
  global g_airplayRotation
  global g_airtunesDebug
  global g_passwordlock
  global g_password
  global g_trialEnable
  global g_activecode
  
  settingsChanged = False
  
  airplayFriendlyName  =__settings__.getSetting("airplaydevicename")
  airplayServerport = int(float(__settings__.getSetting("airplayport")))
  airtunesServerport = int(float(__settings__.getSetting("airtunesport")))
  airplaydataport = int(float(__settings__.getSetting("airplaydataport")))
  airplayrotation = __settings__.getSetting("airplayrotation") == "true"
  airtunesDebug = __settings__.getSetting("airtunesdebug") == "true"
  passwordlock = __settings__.getSetting("airplaylock") == "true"
  password = __settings__.getSetting("airplaypassword")
  trialenable = __settings__.getSetting("airplaytrial") == "true"
  activecode =__settings__.getSetting("activecode")


  if g_airplayServerport != airplayServerport:
    g_airplayServerport = airplayServerport
    settingsChanged = True

  if g_airtunesServerport != airtunesServerport:
    g_airtunesServerport = airtunesServerport
    settingsChanged = True
    
  if g_airplayDataport != airplaydataport:
    g_airplayDataport = airplaydataport
    settingsChanged = True
    
  if g_airplayRotation != airplayrotation:
    g_airplayRotation = airplayrotation
    settingsChanged = True

  if g_airtunesDebug != airtunesDebug:
    g_airtunesDebug = airtunesDebug
    settingsChanged = True

  if g_passwordlock != passwordlock:
    g_passwordlock = passwordlock
    settingsChanged = True

  if g_password != password:
    g_password = password
    settingsChanged = True
    
  if g_trialEnable != trialenable:
    g_trialEnable = trialenable
    settingsChanged = True
    
  if g_activecode != activecode:
    g_activecode = activecode
    settingsChanged = True
    
    
  if g_airplayFriendlyName != airplayFriendlyName:
    g_airplayFriendlyName = airplayFriendlyName
    settingsChanged = True

  return settingsChanged

#handles all settings of airplay and applies them as needed
#returns if a settings have changed
def settings_setup():  
  settingsChanged = False
  settingsChanged = settings_handleAirplaySettings()

  return settingsChanged
  
