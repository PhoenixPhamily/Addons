![alt tag](https://raw.githubusercontent.com/Zanzibar82/plugin.video.streamondemand/master/icon.png)
# Stream On Demand

Son of pelisalacarta:

italian STREAM ON DEMAND

The downloadable zips in release page can be installed directly into Kodi.
Removed adult options and channels.

Special thanks to forum users:

Jesus (for pelisalacarta and his total support)

robalo (for being a reliable master and a skilled a developer)

dentaku65 (for being a vulcano of ideas and a hard worker, and sparring partner in months of sleepless nights)

DrZ3r0 (for being our most skilled developer, author of many important servers' files and caring about
        the most boring/complicated/necessary stuff)

Raùl (for his native "general search" function we found here
      http://www.mimediacenter.info/foro/viewtopic.php?f=22&t=6654&p=24982#p24982 was very handy )

Chryses (for initial, raw, idea about auto-updates)

fenice82 (for editing the useful xml files for channels and for
          adapting pelisalacarta-UI to Streamondemand-PureIta, https://github.com/Fenice82/plugin.video.streamondemand-pureita)

orione7 (for keeping up the pureITA "side project")

costaplus (keep up the good job!)

my girlfriend and his brother for love and support.

...and anyone else supporting the project with their effort. 

The project is on this account of mine just by chance, I am by no means a skilled developer,
but I do my best to support the project and the rising community around it since the very beginning.

Keep in mind in case you fork: STREAM ON DEMAND HAS AN AUTO-UPDATE SYSTEM LINKED TO THIS REPO.

Come and join us: http://www.mimediacenter.info/foro/viewforum.php?f=36 (netiquette first)
